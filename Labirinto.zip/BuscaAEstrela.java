import busca.Estado;

public class BuscaAEstrela {
    private MostraStatusConsole status;

    public BuscaAEstrela(MostraStatusConsole status) {
        this.status = status;
    }

    public Nodo busca(Estado estadoInicial) {
        PriorityQueue<Nodo> abertos = new PriorityQueue<>();
        Set<Estado> fechados = new HashSet<>();
        Nodo inicial = new Nodo(estadoInicial, null);
        abertos.add(inicial);

        while (!abertos.isEmpty()) {
            Nodo atual = abertos.poll();
            if (atual.getEstado().ehMeta()) return atual;

            fechados.add(atual.getEstado());

            for (Estado e : atual.getEstado().sucessores()) {
                if (fechados.contains(e)) continue;
                Nodo n = new Nodo(e, atual);
                abertos.add(n);
            }

            status.mostra(atual);
        }
        return null;
    }
}
