
public class Posicao {
    int linha;
    int coluna;

    public Posicao() {
        this.linha = 0;
        this.coluna = 0;
    }
}